package me.footprint.app.net

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

// ---------------- 请求 / 响应数据类 ----------------

@Serializable
data class LoginRequest(val nickname: String, val password: String)

@Serializable
data class LoginResponse(val user: UserDto? = null)

@Serializable
data class UserDto(val id: Long, val nickname: String, val avatar: String? = null)

@Serializable
data class AppUsage(
    val packageName: String,
    val appName: String,
    val seconds: Long,
)

@Serializable
data class ReportRequest(val date: String, val apps: List<AppUsage>)

@Serializable
data class ReportResponse(val ok: Boolean = false, val serverTime: String? = null, val date: String? = null)

@Serializable
data class UsageListResponse(
    val date: String = "",
    val totalSeconds: Long = 0,
    val apps: List<AppUsage> = emptyList(),
    val lastReportAt: String? = null,
)

@Serializable
data class PartnerResponse(
    val partner: UserDto? = null,
    val date: String = "",
    val totalSeconds: Long = 0,
    val apps: List<AppUsage> = emptyList(),
    val lastReportAt: String? = null,
    val staleMinutes: Long? = null,
)

/** 后端统一用 { error: "..." } 返回错误信息 */
@Serializable
data class ApiErrorBody(val error: String? = null)

/** 把后端的 HTTP 错误变成可读异常，UI 直接展示 message */
class ApiException(message: String, val code: Int = 0) : IOException(message)

// ---------------- 客户端 ----------------

/**
 * OkHttp 单例 + 手写 Cookie 处理。
 *
 * 为什么不用 OkHttp 自带的持久化 CookieJar：
 * 文档 16.5 说得很清楚 —— Cookie 不会自己跨进程可靠地持久化，手动塞最省心。
 * 这里的做法是：
 *   1. 登录响应里的 Set-Cookie 由 [MemoryCookieJar] 在内存里接住（只管当前进程）；
 *   2. 真正落盘走 [Session.saveToken]，值取自 Set-Cookie 的 fp_session；
 *   3. 之后每个请求手动加 `Cookie: fp_session=xxx` 头。
 * 即内存 CookieJar 只做兜底（防止个别逻辑漏加头），落盘和回填都是显式的。
 */
object Api {

    private const val TAG = "FootprintApi"
    private const val COOKIE_NAME = "fp_session"
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    /** kotlinx.serialization 的配置：后端有时会多给字段，忽略未知字段更稳 */
    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        explicitNulls = false
    }

    /** 内存 CookieJar：只用来接住登录时 Set-Cookie 的 fp_session */
    private class MemoryCookieJar : CookieJar {
        @Volatile
        var session: String? = null

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            cookies.firstOrNull { it.name == COOKIE_NAME }?.let { session = it.value }
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> = emptyList()
    }

    private val cookieJar = MemoryCookieJar()

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .cookieJar(cookieJar)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    fun baseUrl(): String = Session.baseUrl()

    /** 拼完整地址；BASE_URL 必须带结尾 "/"，这里再兜一层 */
    private fun url(path: String): String {
        val base = if (baseUrl().endsWith("/")) baseUrl() else baseUrl() + "/"
        return base + path.removePrefix("/")
    }

    // ---------------- 底层请求 ----------------

    private suspend fun send(
        method: String,
        path: String,
        body: String? = null,
        token: String? = null,
    ): String = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(url(path))
        if (token != null) {
            // 显式带上会话 Cookie（文档 16.5：不要指望 OkHttp 自动跨进程持久化）
            builder.header("Cookie", "$COOKIE_NAME=$token")
        }
        val reqBody = body?.toRequestBody(JSON_MEDIA_TYPE)
        builder.method(method, reqBody)
        builder.header("Accept", "application/json")

        val response = try {
            client.newCall(builder.build()).execute()
        } catch (e: IOException) {
            // 网络不通（没连 Wi-Fi / 地址填错 / 后端没起）统一成一句话
            Log.w(TAG, "$method $path 网络失败", e)
            throw ApiException("连不上后端：${e.message ?: "网络错误"}")
        }

        response.use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching {
                    json.decodeFromString(ApiErrorBody.serializer(), text).error
                }.getOrNull()
                throw ApiException(msg?.takeIf { it.isNotBlank() } ?: "HTTP ${resp.code}", resp.code)
            }
            text
        }
    }

    // ---------------- 登录 ----------------

    /**
     * 登录：POST /api/login
     * 成功后 token 同时进内存 CookieJar 和 SharedPreferences，调用方拿到的就是 token。
     */
    suspend fun login(
        nickname: String,
        password: String,
        onToken: (String) -> Unit,
    ): LoginResponse {
        val body = json.encodeToString(LoginRequest.serializer(), LoginRequest(nickname.trim(), password))
        val text = send("POST", "api/login", body)

        val resp = runCatching {
            json.decodeFromString(LoginResponse.serializer(), text)
        }.getOrNull()

        // 没拿到会话说明没连到正确的后端（比如连到了别的服务），直接报错
        val token = cookieJar.session?.takeIf { it.isNotBlank() }
            ?: throw ApiException("登录成功但没拿到会话 Cookie，检查是否连到了正确的后端")
        onToken(token)
        return resp ?: LoginResponse()
    }

    // ---------------- 使用时长 ----------------

    /** PUT /api/usage/report —— 当日累计覆盖写，后端保证幂等 */
    suspend fun report(date: String, apps: List<AppUsage>, token: String): ReportResponse {
        val body = json.encodeToString(ReportRequest.serializer(), ReportRequest(date, apps))
        val text = send("PUT", "api/usage/report", body, token)
        return json.decodeFromString(ReportResponse.serializer(), text)
    }

    /** GET /api/usage/today */
    suspend fun getMyToday(token: String): UsageListResponse {
        val text = send("GET", "api/usage/today", null, token)
        return json.decodeFromString(UsageListResponse.serializer(), text)
    }

    /** GET /api/usage/partner */
    suspend fun getPartner(token: String): PartnerResponse {
        val text = send("GET", "api/usage/partner", null, token)
        return json.decodeFromString(PartnerResponse.serializer(), text)
    }
}
